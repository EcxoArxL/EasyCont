document.addEventListener('DOMContentLoaded', (event) => {
    const menuTrigger = document.querySelector('.menu-trigger');
    const menu = document.querySelector('.menu');
    const mainContent = document.querySelector('main');

    menuTrigger.addEventListener('mouseenter', () => {
        menu.classList.add('open');
        mainContent.classList.add('open');
    });

    menu.addEventListener('mouseleave', () => {
        menu.classList.remove('open');
        mainContent.classList.remove('open');
    });
});


document.querySelectorAll('.texto_abrir').forEach(item => {
    item.addEventListener('click', event => {
        event.preventDefault();
        const targetId = event.target.getAttribute('data-target');
        document.getElementById(targetId).style.display = 'block';
        document.getElementById('fondo_borroso').style.display = 'block';
    });
});

document.querySelectorAll('.cerrar').forEach(item => {
    item.addEventListener('click', event => {
        event.preventDefault();
        const cuadro = event.target.closest('.cuadro');
        if (cuadro) {
            cuadro.style.display = 'none';
        }
        document.getElementById('fondo_borroso').style.display = 'none';
    });
});
