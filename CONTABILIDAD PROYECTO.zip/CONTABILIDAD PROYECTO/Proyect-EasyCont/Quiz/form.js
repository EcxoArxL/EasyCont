var countQues = 0;
var score = 0;

var Quizpreguntas = [
    {
        pregunta: "¿Cómo se clasifica la cuenta: Maquinaria?",
        respuestas: ["Activo", "Capital", "Pasivo", "Ingreso", "Gasto"],
        correcta: 0
        
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Vehículos?",
        respuestas: ["Capital", "Pasivo", "Ingreso", "Activo", "Gasto"],
        correcta: 3
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Comisiones Recibidas?",
        respuestas: ["Activo", "Pasivo", "Capital", "Ingreso", "Gasto"],
        correcta: 3
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Depreciaciones?",
        respuestas: ["Activo", "Pasivo", "Ingreso", "Capital", "Gasto"],
        correcta: 4
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Devoluciones y Rebajas sobre Ventas?",
        respuestas: ["Gasto", "Capital", "Pasivo", "Ingreso", "Activo"],
        correcta: 0
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Gastos de Organización?",
        respuestas: ["Capital", "Pasivo", "Ingreso", "Activo", "Gasto"],
        correcta: 3
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Compras?",
        respuestas: ["Activo", "Pasivo", "Capital", "Ingreso", "Gasto"],
        correcta: 4
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Impuestos Pagados?",
        respuestas: ["Activo", "Gasto", "Pasivo", "Ingreso", "Capital"],
        correcta: 1
    },
    {
        pregunta: "¿Cómo se clasifica la cuenta: Útiles y enseres existencia?",
        respuestas: ["Gasto", "Activo", "Ingreso", "Pasivo", "Capital"],
        correcta: 1

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Proveedores?",
        respuestas: ["Activo", "Gasto", "Capital", "Pasivo", "Ingreso"],
        correcta: 3

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Internet Pagado?",
        respuestas: ["Activo", "Pasivo", "Capital", "Ingreso", "Gasto"],
        correcta: 4

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Cuentas por pagar?",
        respuestas: ["Gasto", "Activo", "Ingreso", "Pasivo", "Capital"],
        correcta: 3
    },
{
        pregunta: "¿Cómo se clasifica la cuenta: IVA por pagar?",
        respuestas: ["Capital", "Pasivo", "Ingreso", "Activo", "Gasto"],
        correcta: 1
    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Herramientas?",
        respuestas: ["Activo", "Pasivo", "Capital", "Ingreso", "Gasto"],
        correcta: 0
    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Hipotecas por pagar",
        respuestas: ["Gasto", "Activo", "Ingreso", "Pasivo", "Capital"],
        correcta: 3
},
{
        pregunta: "¿Cómo se clasifica la cuenta: Marcas y Patentes?",
        respuestas: ["Activo", "Pasivo", "Ingreso", "Capital", "Gasto"],
        correcta: 0
    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Ventas?",
        respuestas: ["Ingreso", "Pasivo", "Activo", "Capital", "Gasto"],
        correcta: 0
    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Intereses Cobrados Anticipados?",
        respuestas: ["Capital", "Pasivo", "Ingreso", "Activo", "Gasto"],
        correcta: 1

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Comisiones Cobradas?",
        respuestas: ["Activo", "Capital", "Pasivo", "Ingreso", "Gasto"],
        correcta: 3

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Documentos por Cobrar?",
        respuestas: ["Activo", "Capital", "Pasivo", "Ingreso", "Gasto"],
        correcta: 0

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Publicidad Pagada Anticipada?",
        respuestas: ["Activo", "Pasivo", "Capital", "Ingreso", "Gasto"],
        correcta: 0

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Palería y Útiles en existencia?",
        respuestas: ["Gasto", "Ingreso", "Pasivo", "Capital", "Activo"],
        correcta: 4

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Mobiliario y Equipo?",
        respuestas: ["Activo", "Pasivo", "Capital", "Ingreso", "Gasto"],
        correcta: 0

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Reserva para aguinaldo?",
        respuestas: ["Activo", "Capital", "Pasivo", "Ingreso", "Gasto"],
        correcta: 2

    },
{
        pregunta: "¿Cómo se clasifica la cuenta: Sueldos pagados por anticipado?",
        respuestas: ["Activo", "Gasto", "Capital", "Ingreso", "Pasivo"],
        correcta: 0
    },
];

document.getElementById("puntuación").textContent = "Puntuación: " + 0;
document.querySelector(".ver-resultados").style.display = "none";
document.querySelector(".quiz").style.display = "none";
document.querySelector(".resultado-final").style.display = "none";

let enQuiz = true; // Variable de estado para verificar si el usuario está en el quiz

function ocultarTodosCuadrosEmergentes() {
    document.getElementById("cuadro-incorrecto").style.display = "none";
    document.getElementById("cuadro-salida").style.display = "none";
}

function mostrarCuadroEmergente(id) {
    ocultarTodosCuadrosEmergentes();
    document.getElementById(id).style.display = "block";
}

document.querySelector(".enviar-respuesta").addEventListener("click", function () {
    var opciones = document.querySelectorAll('input[name="opciones"]');
    var seleccionada;

    opciones.forEach((opcion, index) => {
        if (opcion.checked) {
            seleccionada = index;
        }
    });

    if (seleccionada === Quizpreguntas[countQues].correcta) {
        score += 4;
        document.getElementById("vista-preguntas").innerHTML += "<div class='ques-circle correct'>" + (countQues + 1) + "</div>";
        avanzarPregunta();
    } else {
        score -= 2;
        document.getElementById("vista-preguntas").innerHTML += "<div class='ques-circle incorrect'>" + (countQues + 1) + "</div>";
        mostrarCuadroEmergente("cuadro-incorrecto");
    }

    document.getElementById("puntuación").textContent = "Puntuación: " + score;
});

document.getElementById("boton-siguiente").addEventListener("click", function () {
    ocultarTodosCuadrosEmergentes();
    avanzarPregunta();
});

document.querySelector(".ver-resultados").addEventListener("click", function (event) {
    event.preventDefault();
    document.querySelector(".resultado-final").style.display = "block";

    var correctas = document.getElementById("vista-preguntas").getElementsByClassName("correct").length;

    document.querySelector(".no-preguntas-resueltas").innerHTML = "Has Resuelto " + (countQues + 1) + " preguntas de Contabilidad básica";
    document.querySelector(".correcto-incorrecto").innerHTML = correctas + " Fueron Correctas y " + ((countQues + 1) - correctas) + " fueron Incorrectas";
    document.getElementById("mostrar-puntuación-final").innerHTML = "Tu Puntuación Final es: " + score;

    if (correctas / (countQues + 1) > 0.8) {
        document.querySelector(".observación").innerHTML = "Observación: ¡Excelente!";
    } else if (correctas / (countQues + 1) > 0.6) {
        document.querySelector(".observación").innerHTML = "Observación: Bueno, sigue mejorando.";
    } else if (correctas / (countQues + 1) > 0.4) {
        document.querySelector(".observación").innerHTML = "Observación: Satisfactorio, sigue intentándolo.";
    } else {
        document.querySelector(".observación").innerHTML = "Observación: Insatisfactorio, inténtalo nuevamente.";
    }

    $('html, body').animate({
        scrollTop: $("#mostrar-puntuación-final").offset().top
    }, 1000);

    enQuiz = false;
});

document.getElementById("reiniciar").addEventListener("click", function () {
    location.reload();
});

document.getElementById("volver-menu").addEventListener("click", function () {
    window.location.href = "../Menu/index.html"; 
});

function mostrarPregunta() {
    document.querySelector(".quiz").style.display = "block";
    document.getElementById("preguntas-restantes").textContent = "Pregunta: " + (countQues + 1) + "/" + Quizpreguntas.length;
    document.querySelector(".pregunta h1").innerText = Quizpreguntas[countQues].pregunta;

    for (let i = 0; i < Quizpreguntas[countQues].respuestas.length; i++) {
        document.getElementById("opt" + i).value = Quizpreguntas[countQues].respuestas[i];
        document.getElementById("lb" + i).innerText = Quizpreguntas[countQues].respuestas[i];
    }
}

mostrarPregunta();

function terminarExamen() {
    enQuiz = false;
    mostrarCuadroEmergente("cuadro-salida");
}

function avanzarPregunta() {
    if (countQues < Quizpreguntas.length - 1) {
        countQues++;
        mostrarPregunta();
    } else {
        document.querySelector(".enviar-respuesta").style.display = "none";
        document.querySelector(".ver-resultados").style.display = "unset";
        enQuiz = false;
    }
}

window.addEventListener("blur", function() {
    if (enQuiz) {
        mostrarCuadroEmergente("cuadro-salida");
    }
});

document.getElementById("boton-ir-resultados").addEventListener("click", function () {
    terminarExamen();
    document.querySelector(".resultado-final").style.display = "block";
    document.querySelector(".quiz").style.display = "none";
});

function mostrarCuadroIncorrecto() {
    var respuestaCorrecta = Quizpreguntas[countQues].respuestas[Quizpreguntas[countQues].correcta];
    document.getElementById("respuesta-correcta").textContent = respuestaCorrecta;
    document.getElementById("cuadro-incorrecto").style.display = "block";
    document.querySelector(".enviar-respuesta").disabled = true; 
}

document.getElementById("boton-siguiente").addEventListener("click", function () {
    document.getElementById("cuadro-incorrecto").style.display = "none";
    document.querySelector(".enviar-respuesta").disabled = false; 
    avanzarPregunta();
});

document.addEventListener('visibilitychange', function () {
    if (document.hidden && enQuiz) { 
        mostrarCuadroSalida();
    }
});

function mostrarCuadroSalida() {
    document.getElementById("cuadro-salida").style.display = "block";
    document.querySelector(".enviar-respuesta").disabled = true; 
}

document.getElementById("boton-ir-resultados").addEventListener("click", function () {
    document.getElementById("cuadro-salida").style.display = "none";
    terminarExamen();
});

function terminarExamen() {
    enQuiz = false; 
    document.querySelector(".resultado-final").style.display = "block";

    document.querySelector(".no-preguntas-resueltas").innerHTML = "Has Resuelto " + (countQues + 1) + " preguntas de Contabilidad básica";
    document.querySelector(".correcto-incorrecto").innerHTML = "0 Fueron Correctas y " + (countQues + 1) + " fueron Incorrectas";
    document.getElementById("mostrar-puntuación-final").innerHTML = "Tu Puntuación Final es: 0";

    document.querySelector(".observación").innerHTML = "Observación: No puedes salir de la página mientras estás evaluándote.";

    document.querySelector(".quiz").style.display = "none";

    $('html, body').animate({
        scrollTop: $("#mostrar-puntuación-final").offset().top
    }, 1000);
}

document.querySelector(".ver-resultados").addEventListener("click", function (event) {
    event.preventDefault();
    document.querySelector(".resultado-final").style.display = "block";

    var correctas = document.getElementById("vista-preguntas").getElementsByClassName("correct").length;

    document.querySelector(".no-preguntas-resueltas").innerHTML = "Has Resuelto " + (countQues + 1) + " preguntas de Contabilidad básica";
    document.querySelector(".correcto-incorrecto").innerHTML = correctas + " Fueron Correctas y " + ((countQues + 1) - correctas) + " fueron Incorrectas";
    document.getElementById("mostrar-puntuación-final").innerHTML = "Tu Puntuación Final es: " + score;

    if (correctas / (countQues + 1) > 0.8) {
        document.querySelector(".observación").innerHTML = "Observación: ¡Excelente!";
    } else if (correctas / (countQues + 1) > 0.6) {
        document.querySelector(".observación").innerHTML = "Observación: Bueno, sigue mejorando.";
    } else if (correctas / (countQues + 1) > 0.4) {
        document.querySelector(".observación").innerHTML = "Observación: Satisfactorio, sigue intentándolo.";
    } else {
        document.querySelector(".observación").innerHTML = "Observación: Insatisfactorio, inténtalo nuevamente.";
    }

    document.querySelector(".quiz").style.display = "none";
    
    enQuiz = false;

    $('html, body').animate({
        scrollTop: $("#mostrar-puntuación-final").offset().top
    }, 1000);
});

document.getElementById("reiniciar").addEventListener("click", function () {
    location.reload();
});

document.getElementById("volver-menu").addEventListener("click", function () {
    window.location.href = "../Menu/index.html"; 
});

function mostrarPregunta() {
    document.querySelector(".quiz").style.display = "block";
    document.getElementById("preguntas-restantes").textContent = "Pregunta: " + (countQues + 1) + "/" + Quizpreguntas.length;
    document.querySelector(".pregunta h1").innerText = Quizpreguntas[countQues].pregunta;

    for (let i = 0; i < Quizpreguntas[countQues].respuestas.length; i++) {
        document.getElementById("opt" + i).value = Quizpreguntas[countQues].respuestas[i];
        document.getElementById("lb" + i).innerText = Quizpreguntas[countQues].respuestas[i];
    }
}

mostrarPregunta();

$(document).on('click', 'a[href^="#"]', function(event) {
    event.preventDefault();
    $('html, body').animate({
        scrollTop: $($.attr(this, 'href')).offset().top
    }, 1000);
});
